"use strict";
(() => {
  // src/diagnostics.ts
  var output = document.querySelector("#report");
  var status = document.querySelector("#status");
  async function collect() {
    status.textContent = "Collecting local reports\u2026";
    const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
    const reports = (await Promise.all(tabs.filter((tab) => tab.id !== void 0 && !tab.discarded).map(async (tab) => {
      try {
        const report = await chrome.tabs.sendMessage(tab.id, { type: "diagnostics" }, { frameId: 0 });
        if (Array.isArray(report?.events) && report.events.length) return { tabId: tab.id, ...report };
      } catch {
      }
    }))).filter(Boolean).sort((a, b) => (b.events.at(-1)?.at ?? 0) - (a.events.at(-1)?.at ?? 0)).slice(0, 12);
    output.value = JSON.stringify({
      version: chrome.runtime.getManifest().version,
      browser: navigator.userAgent,
      capturedAt: (/* @__PURE__ */ new Date()).toISOString(),
      reports
    }, null, 2);
    status.textContent = `Ready. ${reports.length} local tab report(s).`;
  }
  document.querySelector("#refresh").addEventListener("click", () => {
    void collect().catch(showError);
  });
  function showError(error) {
    status.textContent = `Could not collect reports: ${String(error)}`;
  }
  document.querySelector("#copy").addEventListener("click", () => {
    void navigator.clipboard.writeText(output.value).then(() => {
      status.textContent = "Copied. Paste the report into this chat.";
    }).catch(() => {
      output.focus();
      output.select();
      status.textContent = "Press Cmd+C to copy the selected report.";
    });
  });
  void collect().catch(showError);
})();
