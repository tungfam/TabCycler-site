"use strict";
(() => {
  // src/model.ts
  var MAX_CYCLER_TABS = 8;
  function touch(ids, id) {
    return [id, ...ids.filter((value) => value !== id)];
  }
  function orderedTabs(ids, tabs, current) {
    const byId = new Map(tabs.map((tab) => [tab.id, tab]));
    return [.../* @__PURE__ */ new Set([current, ...ids, ...tabs.map((tab) => tab.id)])].flatMap((id) => byId.has(id) ? [byId.get(id)] : []).slice(0, MAX_CYCLER_TABS);
  }

  // src/injection.ts
  var inFlight = /* @__PURE__ */ new Map();
  async function attach(tabId) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { type: "ping" }, { frameId: 0 });
      if (response?.ready) return;
    } catch {
    }
    await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ["content.js"] });
  }
  function ensureContent(tabId) {
    const existing = inFlight.get(tabId);
    if (existing) return existing;
    const task = attach(tabId).finally(() => {
      inFlight.delete(tabId);
    });
    inFlight.set(tabId, task);
    return task;
  }
  async function initializeOpenTabs() {
    const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
    await Promise.allSettled(tabs.filter((tab) => tab.id !== void 0 && !tab.discarded).map((tab) => ensureContent(tab.id)));
  }

  // src/background.ts
  chrome.runtime.onInstalled.addListener(() => {
    void initializeOpenTabs().catch(console.error);
  });
  async function readState() {
    return await chrome.storage.session.get(["mru", "pending"]);
  }
  var queue = Promise.resolve();
  function record(id) {
    queue = queue.then(async () => {
      const { mru = [] } = await readState();
      await chrome.storage.session.set({ mru: touch(mru, id) });
    }).catch(console.error);
  }
  chrome.tabs.onActivated.addListener(({ tabId }) => record(tabId));
  chrome.tabs.onRemoved.addListener((id) => {
    queue = queue.then(async () => {
      const { mru = [] } = await readState();
      await chrome.storage.session.set({ mru: mru.filter((value) => value !== id) });
    }).catch(console.error);
  });
  chrome.windows.onFocusChanged.addListener((windowId) => {
    if (windowId < 0) return;
    void chrome.tabs.query({ windowId, active: true }).then(([tab]) => {
      if (tab?.id !== void 0) record(tab.id);
    }).catch(console.error);
  });
  async function open(tab, releaseToSelect, openedAt) {
    if (tab.id === void 0) return;
    try {
      await ensureContent(tab.id);
    } catch {
      await unavailable(tab.id);
      return;
    }
    if (releaseToSelect) {
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { type: "cycle", openedAt }, { frameId: 0 });
        if (response?.handled) return;
      } catch {
      }
    }
    await queue;
    const tabs = await chrome.tabs.query({ windowId: tab.windowId });
    const { mru = [] } = await readState();
    const items = orderedTabs(mru, tabs.flatMap((item) => item.id === void 0 ? [] : [{
      id: item.id,
      title: item.title || "Untitled tab",
      favicon: item.favIconUrl,
      hostname: hostname(item.url)
    }]), tab.id);
    const message = {
      type: "open",
      token: crypto.randomUUID(),
      tabs: items,
      openedAt,
      releaseToSelect
    };
    await chrome.storage.session.set({ pending: {
      token: message.token,
      source: tab.id,
      windowId: tab.windowId,
      ids: items.map((item) => item.id),
      openedAt
    } });
    try {
      await chrome.tabs.sendMessage(tab.id, message, { frameId: 0 });
      await chrome.action.setBadgeText({ tabId: tab.id, text: "" });
      await chrome.action.setTitle({ tabId: tab.id, title: "Open TabCycler (arrows + Enter fallback)" });
    } catch {
      await chrome.storage.session.remove("pending");
      await unavailable(tab.id);
    }
  }
  async function unavailable(tabId) {
    await chrome.action.setBadgeText({ tabId, text: "!" });
    await chrome.action.setTitle({
      tabId,
      title: "TabCycler unavailable here. Use an HTTP(S) page and allow website access in extension settings."
    });
    console.warn("TabCycler: page is restricted, unavailable, or site access is denied.");
  }
  function hostname(url) {
    try {
      return new URL(url || "").hostname;
    } catch {
      return "";
    }
  }
  var commands = Promise.resolve();
  chrome.commands.onCommand.addListener((command, tab) => {
    if (!["open-switcher", "duplicate-tab"].includes(command)) return;
    const openedAt = Date.now();
    console.info("TabCycler command delivered:", command);
    commands = commands.then(async () => {
      const target = tab ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
      if (command === "duplicate-tab") {
        if (target?.id === void 0) return;
        const source = await chrome.tabs.get(target.id);
        const copy = await chrome.tabs.duplicate(target.id);
        if (copy?.id === void 0) return;
        await chrome.tabs.move(copy.id, { index: source.index + 1 });
        await chrome.tabs.update(copy.id, { active: true });
      } else if (target) await open(target, true, openedAt);
    }).catch(console.error);
  });
  chrome.action.onClicked.addListener((tab) => {
    void open(tab, false, Date.now()).catch(console.error);
  });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || sender.tab?.id === void 0) return;
    if (!["flush", "commit", "cancel"].includes(message?.type)) return;
    void (async () => {
      if (message.type === "flush") {
        let draining;
        do {
          draining = commands;
          await draining;
        } while (draining !== commands);
      }
      const { pending } = await readState();
      if (!pending || pending.token !== message.token || pending.source !== sender.tab.id) {
        return { ok: false, error: "Switcher session expired. Reopen it." };
      }
      if (message.type === "flush") return { ok: true };
      await chrome.storage.session.remove("pending");
      if (message.type === "cancel") return { ok: true };
      if (Date.now() - pending.openedAt > 6e4 || !pending.ids.includes(message.id)) {
        return { ok: false, error: "Selection expired. Reopen the switcher." };
      }
      const [source, target] = await Promise.all([
        chrome.tabs.get(pending.source),
        chrome.tabs.get(message.id)
      ]);
      if (!source.active || target.windowId !== pending.windowId) {
        return { ok: false, error: "Tab or window changed. Reopen the switcher." };
      }
      const window = await chrome.windows.get(pending.windowId);
      if (!window.focused) return { ok: false, error: "Chrome lost focus. Selection cancelled." };
      await chrome.tabs.update(message.id, { active: true });
      return { ok: true };
    })().then(respond).catch((error) => respond({ ok: false, error: String(error) }));
    return true;
  });
})();
