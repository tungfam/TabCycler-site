"use strict";
(() => {
  // src/model.ts
  var MAX_CYCLER_TABS = 8;
  function step(index2, delta, length) {
    return length ? (index2 + delta + length) % length : 0;
  }

  // src/cycler.ts
  var css = `
:host{all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:grid!important;place-items:center!important;pointer-events:none!important;color-scheme:dark!important}
*{box-sizing:border-box}button{font:inherit;color:inherit}button:focus-visible{outline:2px solid #a7c7ff;outline-offset:4px}
.cycler{pointer-events:auto;width:min(1040px,calc(100vw - 48px));padding:24px;background:linear-gradient(145deg,#30323af5,#1b1d24fa);color:#f7f8ff;border:1px solid #ffffff24;border-radius:26px;box-shadow:0 28px 100px #0007,0 2px 8px #0004,inset 0 1px #ffffff0c;backdrop-filter:blur(28px);font:13px -apple-system,BlinkMacSystemFont,system-ui,sans-serif;animation:appear .12s ease-out}
header,footer,.hint{display:flex;align-items:center}header{margin-bottom:20px}.brand{font-size:16px;font-weight:650;letter-spacing:-.3px}
.rail{display:flex;gap:10px;overflow-x:auto;padding:6px 4px 12px;margin:0 -4px;scrollbar-width:thin;scrollbar-color:#ffffff20 transparent;scroll-behavior:smooth;overscroll-behavior:contain}.card{position:relative;flex:0 0 112px;min-width:0;min-height:136px;border:1px solid #ffffff0c;border-radius:16px;background:#ffffff04;color:#aeb3c5;padding:16px 10px 12px;display:flex;align-items:center;flex-direction:column;gap:12px;transition:background .1s,border-color .1s,box-shadow .1s;cursor:pointer;user-select:none}.card:hover{background:#ffffff0b}.card[aria-selected=true]{color:#fff;background:#8cabff1c;border-color:#a5c4ff;box-shadow:0 0 0 2px #a5c4ff20,inset 0 1px #ffffff12}.icon{display:grid;place-items:center;position:relative;width:46px;height:46px;border-radius:12px;background:linear-gradient(145deg,#727b9955,#424b6544);box-shadow:0 3px 10px #0002;color:#e0e8ff;font-size:23px;font-weight:600;flex-shrink:0}.icon img{position:absolute;width:28px;height:28px;object-fit:contain}.card-title{font-size:12px;font-weight:550;line-height:1.35;text-align:center;width:100%;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow-wrap:anywhere}
.selection{margin:18px 0 20px;min-width:0}.selection-title{font-size:19px;line-height:1.35;letter-spacing:-.35px;font-weight:600;margin:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.domain{color:#9ea5bb;font-size:12px;margin:5px 0 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
footer{border-top:1px solid #ffffff12;padding-top:16px;justify-content:space-between;gap:14px;flex-wrap:wrap}.hint{gap:7px;color:#aeb5c9;font-size:11px}.hint strong{color:#e4eaff;font-weight:550}kbd{font:11px -apple-system,system-ui,sans-serif;background:#ffffff09;border:1px solid #ffffff16;border-bottom-color:#ffffff28;border-radius:5px;min-width:22px;padding:3px 5px;text-align:center;color:#d5dbee}.error{color:#ffd6a0;background:#ffb75d12;border-radius:8px;padding:10px;line-height:1.5;margin-top:12px}
/* Move the selection border immediately; only the card background fades. */
.card{transition-property:background}
@keyframes appear{from{opacity:0;transform:translateY(5px) scale(.99)}to{opacity:1;transform:none}}
@media(max-width:600px){.cycler{width:calc(100vw - 24px);padding:18px;border-radius:20px}.card{flex-basis:100px;min-height:125px}.selection-title{font-size:17px}.hint{font-size:10px}footer{gap:12px}}
@media(prefers-reduced-motion:reduce){.cycler{animation:none}.rail{scroll-behavior:auto}.card{transition:none}}
`;
  function element(tag, className = "", text = "") {
    const node = document.createElement(tag);
    node.className = className;
    node.textContent = text;
    return node;
  }
  var views = /* @__PURE__ */ new WeakMap();
  function createCard(tab, position, selectIndex) {
    const card = element("button", "card");
    card.type = "button";
    card.role = "option";
    card.id = `tab-${position}`;
    card.dataset.control = card.id;
    card.ariaLabel = `${tab.title}${position === 0 ? ", current tab" : ""}`;
    card.title = tab.title;
    card.onclick = () => selectIndex(position);
    const icon = element("span", "icon", (tab.hostname || tab.title).charAt(0).toUpperCase());
    icon.ariaHidden = "true";
    if (tab.favicon && /^(https?:|data:image\/)/i.test(tab.favicon)) {
      const image = element("img");
      image.alt = "";
      image.referrerPolicy = "no-referrer";
      image.onload = () => {
        icon.firstChild?.remove();
      };
      image.onerror = () => image.remove();
      image.src = tab.favicon;
      icon.append(image);
    }
    card.append(icon, element("span", "card-title", tab.title));
    return card;
  }
  function updateSelection(root2, view, session2, index2, error2, selectIndex) {
    const focused = root2.activeElement;
    session2.tabs.forEach((tab, position) => {
      let card = view.cards.get(position);
      if (!card) {
        card = createCard(tab, position, selectIndex);
        view.cards.set(position, card);
        view.rail.append(card);
      }
      card.tabIndex = position === index2 ? 0 : -1;
      card.ariaSelected = String(position === index2);
    });
    const selected = session2.tabs[index2];
    view.rail.setAttribute("aria-activedescendant", `tab-${index2}`);
    view.title.textContent = selected?.title || "No tabs";
    view.domain.textContent = selected?.hostname || (index2 === 0 ? "Current tab" : "Tab in this window");
    view.notice.hidden = !error2;
    view.notice.textContent = error2;
    const selectedCard = view.cards.get(index2);
    selectedCard?.scrollIntoView?.({ block: "nearest", inline: "nearest" });
    if (focused && !focused.isConnected) selectedCard?.focus({ preventScroll: true });
  }
  function renderCycler(root2, session2, index2, error2, selectIndex) {
    const existing = views.get(root2);
    if (existing?.token === session2.token) {
      updateSelection(root2, existing, session2, index2, error2, selectIndex);
      return;
    }
    const style = element("style");
    style.textContent = css;
    const panel = element("section", "cycler");
    panel.role = "dialog";
    panel.ariaLabel = "Tab Cycler";
    panel.style.maxWidth = `${Math.max(620, Math.min(MAX_CYCLER_TABS, session2.tabs.length) * 122 + 40)}px`;
    const header = element("header");
    header.append(element("div", "brand", "Tab Cycler"));
    const rail = element("div", "rail");
    rail.role = "listbox";
    rail.ariaLabel = "Recent tabs";
    rail.style.justifyContent = "safe center";
    const selection = element("div", "selection");
    selection.setAttribute("aria-live", "polite");
    const title = element("h2", "selection-title");
    const domain = element("p", "domain");
    selection.append(title, domain);
    const footer = element("footer");
    const hint = element("div", "hint");
    hint.append(
      element("kbd", "", "\u2190"),
      element("kbd", "", "\u2192"),
      element("span", "", "Browse"),
      element("span", "", "\xB7"),
      element("strong", "", session2.releaseToSelect ? "Shortcut again \u2192 Next" : "Enter to switch")
    );
    const release = element("span", "hint", session2.releaseToSelect ? "Release \u2318 to switch" : "Choose, then press Enter");
    footer.append(hint, release);
    panel.append(header, rail, selection, footer);
    const notice = element("p", "error");
    notice.role = "alert";
    notice.hidden = true;
    panel.append(notice);
    root2.replaceChildren(style, panel);
    const view = { token: session2.token, rail, cards: /* @__PURE__ */ new Map(), title, domain, notice };
    views.set(root2, view);
    updateSelection(root2, view, session2, index2, error2, selectIndex);
  }

  // src/content.ts
  var DISPOSE_EVENT = "__tabcycler_dispose_v1__";
  document.dispatchEvent(new Event(DISPOSE_EVENT));
  var lifecycle = new AbortController();
  var lastMetaUp = 0;
  var session;
  var index = 0;
  var host;
  var root;
  var timer;
  var revealTimer;
  var busy = false;
  var flushing = false;
  var error = "";
  var finishedAt = -1;
  var cancelledAt = -1;
  var log = [];
  var previousFocus = null;
  function trace(value) {
    log.push(`${(/* @__PURE__ */ new Date()).toLocaleTimeString()} ${value}`);
    if (log.length > 8) log.shift();
    console.debug("[TabCycler]", value);
  }
  function remove(restoreFocus = true) {
    clearTimeout(timer);
    clearTimeout(revealTimer);
    finishedAt = Date.now();
    host?.remove();
    host = void 0;
    root = void 0;
    session = void 0;
    busy = false;
    flushing = false;
    if (restoreFocus && previousFocus?.isConnected && document.hasFocus()) previousFocus.focus({ preventScroll: true });
    previousFocus = null;
  }
  function cancel(reason) {
    cancelledAt = Date.now();
    if (!session) return;
    trace(`cancel: ${reason}`);
    void chrome.runtime.sendMessage({ type: "cancel", token: session.token }).catch(() => {
    });
    remove();
  }
  async function commit(reason) {
    if (!session || busy || !session.tabs.length) return;
    const committing = session;
    clearTimeout(revealTimer);
    busy = true;
    flushing = true;
    trace(`select: ${reason}`);
    try {
      const ready = await chrome.runtime.sendMessage({ type: "flush", token: committing.token });
      if (session !== committing) return;
      flushing = false;
      if (!ready?.ok) {
        error = ready?.error || "Could not finish selecting. Reopen the cycler.";
        trace(error);
        busy = false;
        reveal();
        return;
      }
      const result = await chrome.runtime.sendMessage({
        type: "commit",
        token: session.token,
        id: session.tabs[index].id
      });
      if (session !== committing) return;
      if (!result?.ok) {
        error = result?.error || "No response from service worker";
        trace(error);
        busy = false;
        reveal();
        return;
      }
      remove();
    } catch (cause) {
      if (session !== committing) return;
      error = String(cause);
      trace(error);
      busy = false;
      flushing = false;
      reveal();
    }
  }
  function render() {
    if (!session || !root) return;
    renderCycler(
      root,
      session,
      index,
      error,
      (position) => {
        if (!busy) {
          index = position;
          render();
        }
      }
    );
  }
  function navigate(delta, allowDuringFlush = false) {
    if (!session || busy && !(flushing && allowDuringFlush)) return;
    index = step(index, delta, session.tabs.length);
    render();
  }
  function reveal() {
    if (!session) return;
    if (!host) {
      host = document.createElement("div");
      root = host.attachShadow({ mode: "closed" });
      (document.body || document.documentElement).append(host);
    }
    render();
  }
  function suppress(event) {
    event.preventDefault();
    event.stopImmediatePropagation();
  }
  window.addEventListener("keydown", (event) => {
    if (!session) return;
    if (["ArrowLeft", "ArrowRight", "Enter"].includes(event.key)) {
      suppress(event);
      trace(`keydown ${event.key} meta=${event.metaKey} cancelable=${event.cancelable} prevented=${event.defaultPrevented}`);
      if (event.key === "Enter") {
        void commit("Enter fallback");
        return;
      }
      navigate(event.key === "ArrowRight" ? 1 : -1);
    }
  }, { capture: true, passive: false, signal: lifecycle.signal });
  window.addEventListener("keyup", (event) => {
    if (event.key === "Meta") lastMetaUp = Date.now();
    if (!session) return;
    if (event.key === "Meta" && !event.metaKey && session.releaseToSelect) {
      suppress(event);
      void commit("Meta keyup");
    } else if (["ArrowLeft", "ArrowRight", "Enter"].includes(event.key)) suppress(event);
  }, { capture: true, passive: false, signal: lifecycle.signal });
  window.addEventListener("blur", () => cancel("focus lost"), { signal: lifecycle.signal });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) cancel("page hidden");
  }, { signal: lifecycle.signal });
  window.addEventListener("pagehide", () => cancel("navigation"), { signal: lifecycle.signal });
  function onMessage(message, _sender, respond) {
    if (message?.type === "ping") {
      respond({ ready: true });
      return;
    }
    if (message?.type === "cycle") {
      if (session || message.openedAt < finishedAt || message.openedAt <= cancelledAt) {
        if (session?.releaseToSelect) navigate(1, true);
        respond({ handled: true });
      } else respond({ handled: false });
      return;
    }
    if (message?.type !== "open") return;
    if (session) cancel("reopened");
    session = { ...message, tabs: message.tabs.slice(0, MAX_CYCLER_TABS) };
    index = session.tabs.length > 1 ? 1 : 0;
    error = "";
    if (message.openedAt <= cancelledAt || message.releaseToSelect && !document.hasFocus()) {
      cancel("cancelled during initialization");
      respond({ ok: true });
      return;
    }
    trace(`opened ${message.releaseToSelect ? "Command release" : "Enter"} mode; focused=${document.hasFocus()}`);
    previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    timer = setTimeout(() => cancel("60 second timeout"), 6e4);
    respond({ ok: true });
    if (message.releaseToSelect && lastMetaUp >= message.openedAt && document.hasFocus()) {
      void commit("Meta keyup received during initialization");
    } else if (message.releaseToSelect) {
      revealTimer = setTimeout(() => {
        if (!busy) reveal();
      }, Math.max(0, 200 - (Date.now() - message.openedAt)));
    } else {
      reveal();
    }
  }
  chrome.runtime.onMessage.addListener(onMessage);
  document.addEventListener(DISPOSE_EVENT, () => {
    lifecycle.abort();
    remove(false);
    try {
      chrome.runtime.onMessage.removeListener(onMessage);
    } catch {
    }
  }, { signal: lifecycle.signal });
})();
