"use strict";
(() => {
  // src/model.ts
  var MAX_CYCLER_TABS = 8;
  function touch(ids, id) {
    return [id, ...ids.filter((value) => value !== id)];
  }
  function orderedTabs(ids, tabs, current) {
    const byId = new Map(tabs.map((tab) => [tab.id, tab]));
    return [.../* @__PURE__ */ new Set([current, ...ids, ...tabs.map((tab) => tab.id)])].flatMap((id) => byId.has(id) ? [byId.get(id)] : []).slice(0, MAX_CYCLER_TABS);
  }

  // src/injection.ts
  var inFlight = /* @__PURE__ */ new Map();
  async function attach(tabId) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { type: "ping" }, { frameId: 0 });
      if (response?.ready) return;
    } catch {
    }
    await chrome.scripting.executeScript({
      target: { tabId, frameIds: [0] },
      files: ["content.js"],
      injectImmediately: true
    });
  }
  function ensureContent(tabId) {
    const existing = inFlight.get(tabId);
    if (existing) return existing;
    const task = attach(tabId).finally(() => {
      inFlight.delete(tabId);
    });
    inFlight.set(tabId, task);
    return task;
  }
  async function initializeOpenTabs() {
    const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
    await Promise.allSettled(tabs.filter((tab) => tab.id !== void 0 && !tab.discarded).map((tab) => ensureContent(tab.id)));
  }

  // src/favicons.ts
  var cache = /* @__PURE__ */ new Map();
  var pending = /* @__PURE__ */ new Map();
  var MAX_ICONS = 64;
  var MAX_DATA_LENGTH = 32768;
  var MAX_AGE = 30 * 6e4;
  var initialized;
  var dirty = false;
  async function initialize() {
    initialized ??= (async () => {
      try {
        const { faviconCache = [] } = await chrome.storage.session.get("faviconCache");
        for (const entry of faviconCache.slice(-MAX_ICONS)) {
          if (typeof entry.key === "string" && typeof entry.src === "string" && entry.src.startsWith("data:image/png;base64,") && entry.src.length <= MAX_DATA_LENGTH && Date.now() - entry.at < MAX_AGE) cache.set(entry.key, entry);
        }
      } catch {
      }
    })();
    await initialized;
  }
  async function loadIcon(tab) {
    if (!tab.url || !/^https?:/i.test(tab.url)) return;
    const key = `${tab.url}
${tab.favIconUrl || ""}`;
    const hit = cache.get(key);
    if (hit && Date.now() - hit.at < MAX_AGE) {
      cache.delete(key);
      cache.set(key, hit);
      return hit.src;
    }
    let request = pending.get(key);
    if (!request) {
      request = (async () => {
        try {
          const url = new URL(chrome.runtime.getURL("_favicon/"));
          url.searchParams.set("pageUrl", tab.url);
          url.searchParams.set("size", "32");
          const response = await fetch(url, { signal: AbortSignal.timeout(150) });
          if (!response.ok) return;
          const bytes = new Uint8Array(await response.arrayBuffer());
          const signature = [137, 80, 78, 71, 13, 10, 26, 10];
          if (bytes.length > 24e3 || !signature.every((value, index) => bytes[index] === value)) return;
          const src = `data:image/png;base64,${btoa(String.fromCharCode(...bytes))}`;
          cache.delete(key);
          cache.set(key, { key, src, at: Date.now() });
          dirty = true;
          while (cache.size > MAX_ICONS) cache.delete(cache.keys().next().value);
          return src;
        } catch {
          return void 0;
        }
      })();
      pending.set(key, request);
    }
    try {
      return await request;
    } finally {
      pending.delete(key);
    }
  }
  async function cachedFavicons(tabs) {
    await initialize();
    const result = /* @__PURE__ */ new Map();
    await Promise.all(tabs.map(async (tab) => {
      const src = await loadIcon(tab);
      if (tab.id !== void 0 && src) result.set(tab.id, src);
    }));
    if (dirty) {
      try {
        await chrome.storage.session.set({ faviconCache: Array.from(cache.values()) });
        dirty = false;
      } catch {
      }
    }
    return result;
  }

  // src/background.ts
  chrome.runtime.onInstalled.addListener(() => {
    void initializeOpenTabs().catch(console.error);
  });
  async function readState() {
    return await chrome.storage.session.get(["mru", "pending"]);
  }
  var queue = Promise.resolve();
  function record(id) {
    queue = queue.then(async () => {
      const { mru = [] } = await readState();
      await chrome.storage.session.set({ mru: touch(mru, id) });
    }).catch(console.error);
  }
  chrome.tabs.onActivated.addListener(({ tabId }) => record(tabId));
  chrome.tabs.onRemoved.addListener((id) => {
    queue = queue.then(async () => {
      const { mru = [] } = await readState();
      await chrome.storage.session.set({ mru: mru.filter((value) => value !== id) });
    }).catch(console.error);
  });
  chrome.windows.onFocusChanged.addListener((windowId) => {
    if (windowId < 0) return;
    void chrome.tabs.query({ windowId, active: true }).then(([tab]) => {
      if (tab?.id !== void 0) record(tab.id);
    }).catch(console.error);
  });
  async function open(tab, releaseToSelect, openedAt) {
    if (tab.id === void 0) return;
    try {
      await ensureContent(tab.id);
    } catch {
      await unavailable(tab.id);
      return;
    }
    if (releaseToSelect) {
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { type: "cycle", openedAt }, { frameId: 0 });
        if (response?.handled) return;
      } catch {
      }
    }
    await queue;
    const tabs = await chrome.tabs.query({ windowId: tab.windowId });
    const { mru = [] } = await readState();
    const items = orderedTabs(mru, tabs.flatMap((item) => item.id === void 0 ? [] : [{
      id: item.id,
      title: item.title || "Untitled tab",
      hostname: hostname(item.url)
    }]), tab.id);
    const icons = await cachedFavicons(tabs.filter((tab2) => items.some((item) => item.id === tab2.id)));
    for (const item of items) item.favicon = icons.get(item.id);
    const message = {
      type: "open",
      token: crypto.randomUUID(),
      tabs: items,
      openedAt,
      releaseToSelect
    };
    await chrome.storage.session.set({ pending: {
      token: message.token,
      source: tab.id,
      windowId: tab.windowId,
      ids: items.map((item) => item.id),
      openedAt
    } });
    try {
      await chrome.tabs.sendMessage(tab.id, message, { frameId: 0 });
      await chrome.action.setBadgeText({ tabId: tab.id, text: "" });
      await chrome.action.setTitle({ tabId: tab.id, title: "Open TabCycler (arrows + Enter fallback)" });
    } catch {
      await chrome.storage.session.remove("pending");
      await unavailable(tab.id);
    }
  }
  async function unavailable(tabId) {
    await chrome.action.setBadgeText({ tabId, text: "!" });
    await chrome.action.setTitle({
      tabId,
      title: "TabCycler unavailable here. Use an HTTP(S) page and allow website access in extension settings."
    });
    console.warn("TabCycler: page is restricted, unavailable, or site access is denied.");
  }
  function hostname(url) {
    try {
      return new URL(url || "").hostname;
    } catch {
      return "";
    }
  }
  var commands = Promise.resolve();
  chrome.commands.onCommand.addListener((command, tab) => {
    if (!["open-switcher", "duplicate-tab"].includes(command)) return;
    const openedAt = Date.now();
    console.info("TabCycler command delivered:", command);
    commands = commands.then(async () => {
      const target = tab ?? (await chrome.tabs.query({ active: true, lastFocusedWindow: true }))[0];
      if (command === "duplicate-tab") {
        if (target?.id === void 0) return;
        const source = await chrome.tabs.get(target.id);
        const copy = await chrome.tabs.duplicate(target.id);
        if (copy?.id === void 0) return;
        await chrome.tabs.move(copy.id, { index: source.index + 1 });
        await chrome.tabs.update(copy.id, { active: true });
      } else if (target) await open(target, true, openedAt);
    }).catch(console.error);
  });
  chrome.action.onClicked.addListener((tab) => {
    void open(tab, false, Date.now()).catch(console.error);
  });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || sender.frameId !== 0 || sender.tab?.id === void 0) return;
    if (!["flush", "commit", "cancel"].includes(message?.type)) return;
    void (async () => {
      if (message.type === "flush") {
        let draining;
        do {
          draining = commands;
          await draining;
        } while (draining !== commands);
      }
      const { pending: pending2 } = await readState();
      if (!pending2 || pending2.token !== message.token || pending2.source !== sender.tab.id) {
        return { ok: false, error: "Switcher session expired. Reopen it." };
      }
      if (message.type === "flush") return { ok: true };
      await chrome.storage.session.remove("pending");
      if (message.type === "cancel") return { ok: true };
      if (Date.now() - pending2.openedAt > 6e4 || !pending2.ids.includes(message.id)) {
        return { ok: false, error: "Selection expired. Reopen the switcher." };
      }
      const [source, target] = await Promise.all([
        chrome.tabs.get(pending2.source),
        chrome.tabs.get(message.id)
      ]);
      if (!source.active || target.windowId !== pending2.windowId) {
        return { ok: false, error: "Tab or window changed. Reopen the switcher." };
      }
      const window = await chrome.windows.get(pending2.windowId);
      if (!window.focused) return { ok: false, error: "Chrome lost focus. Selection cancelled." };
      await chrome.tabs.update(message.id, { active: true });
      return { ok: true };
    })().then(respond).catch((error) => respond({ ok: false, error: String(error) }));
    return true;
  });
})();
